Build a multi-layer deep neural network step-by-step from scratch and implement it for image classification
